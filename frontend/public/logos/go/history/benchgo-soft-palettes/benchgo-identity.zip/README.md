# Go 家族 · 小角品牌延展

当前修正版的基准：小角身体、双眼、切角的几何保持一致，产品特征通过配色和外围结构表达。

- DraftGo：保留既有轨道与橙色模块；原文件在完整包的 `DraftGo-original/` 中。
- RouterGo：彩色标志与应用图标沿用上一版；暖红、分流线路、箭头和连接端点。
- SelfGo：纸白小角、松绿切角，前后错落的画布位于身体后方。双眼保持原始眼距。
- BenchGo：去掉左右代码括号，保留顶部活动标签、分隔线与光标。围绕年轻、舒服的定位，当前推荐晴空蓝与奶油黄，另提供奶油杏、鼠尾草绿、柔雾紫。身体、双眼与切角保持标准几何；顶部细节避开双眼与切角。

## 文件用途

| 后缀 | 用途 |
| --- | --- |
| `-mark.svg` / `.png` | 透明背景彩色标志 |
| `-app.svg` / `.png` | 应用图标，PNG 为 1024 × 1024 |
| `-mono.svg` / `.png` | 黑色单色版，眼睛为透明负形 |
| `-reverse.svg` / `.png` | 白色反白版，用于深色背景 |
| `-icon-16/32/48/64.png` | 网站及小尺寸使用 |
| `-icon-180/192/512.png` | 移动设备及 Web 应用使用 |
| `-favicon.svg` / `.ico` | 网站 favicon，ICO 含 16、32、48、64 像素 |

SVG 可自由缩放。请等比缩放整图，不要单独挪动或拉伸双眼、身体、切角。16 像素主要保留小角和品牌色，外围细节在 32 像素以上更清晰。BenchGo 的 favicon 与 16–64 像素 PNG 使用简化版：保留标准身体、双眼与切角，去掉顶部标签与光标。

身体为 600 × 380，圆角 R95；双眼各 90 × 130、R45，中心分别为 (168,190)、(306,190)；切角连接 (410,380) 与 (600,190)。

`palette.json` 包含品牌色。`go-family-board.png` 是四款横向对比图。

BenchGo 新增四组柔和配色，采用同一形态，首页可直接切换。之前的四组主色参考保留在折叠区。SVG / PNG 下载对应当前所选配色，当前推荐设为默认，单色与反白为八组共用。

| 配色 | 文件前缀 | 身体 / 切角 / 光标 |
| --- | --- | --- |
| 晴空蓝（推荐） | `benchgo-` | `#89B9D8` / `#F3D89B` / `#FFF6E4` |
| 奶油杏 | `benchgo-apricot-` | `#F2C8A9` / `#99B9B0` / `#77998D` |
| 鼠尾草绿 | `benchgo-sage-` | `#ABC5B1` / `#EDDCAD` / `#E0BA8D` |
| 柔雾紫 | `benchgo-lilac-` | `#B8AFD8` / `#F0CCA9` / `#F8E8CA` |
| 深海蓝（之前的参考） | `benchgo-ice-` | `#30496B` / `#8ACEDA` / `#EAC793` |
| 雾蓝灰 | `benchgo-mist-` | `#829AA8` / `#C5DDE0` / `#F4D49F` |
| 暖砂白 | `benchgo-sand-` | `#E5DACA` / `#8B9EAD` / `#B98455` |
| 石墨黑（原配色） | `benchgo-mint-` | `#26363B` / `#78CBA8` / `#E3B96F` |

`benchgo-palettes.json` 包含全部配色与文件前缀，`group` 区分当前柔和方向与之前的参考。`benchgo-palette-board.png` 展示四组柔和配色。`benchgo-comparison.png` 展示去掉左右括号前后的设计。BenchGo 图标包包含八组配色的标志、应用图标、favicon、多尺寸 PNG 及共用的单色、反白版本。

四组柔和配色使用深色双眼，以保持小尺寸下的面部辨识。深海蓝、雾蓝灰、石墨黑使用浅色双眼，暖砂白使用深灰蓝双眼。浅色身体方案的网页文字使用独立深色，具体值见 `benchgo-palettes.json`。

历史版本位于网站资产目录 `logos/go/history/`：`benchgo-v2/` 为紫色停靠线版本，`benchgo-editor-mint/` 为带左右括号的薄荷色编辑器版本，`benchgo-accent-palettes/` 为深色主调的配色研究，`benchgo-body-palettes/` 为推荐深海蓝时的完整导出。

工程源文件：`scripts/go_identity_geometry.py`。导出：`python scripts/build_go_identities.py`。正式小角素材库未改动。
