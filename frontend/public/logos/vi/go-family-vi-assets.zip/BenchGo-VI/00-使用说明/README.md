# BenchGo 完整 VI 资产交付包

版本 1.0 / 卓越构建 / 数字产品 RGB 交付

## 从这里开始

1. 阅读 01-品牌规范/品牌规范手册.pdf；原展板提供总览，手册补全规则。
2. 网站或文档优先选 02-品牌标识/horizontal-color.svg；只需图形选 symbol-color.svg。
3. 深色背景选 *-reverse.svg，反白透明 PNG 在白色查看器中看起来是空白，属正常情况。
4. 应用图标使用 03-应用图标；Web 接入示例可本地打开，部署时调整路径。
5. 开发使用 04-色彩与字体/design-tokens.json 或 variables.css。
6. 模板 SVG 可直接在支持 SVG 的编辑器中打开；修改文字后检查字体与排版，再输出 PNG。

## 目录

- 00-使用说明
- 01-品牌规范
- 02-品牌标识
- 03-应用图标
- 04-色彩与字体
- 05-辅助视觉
- 06-应用模板
- 07-源文件

## 决策与适用范围

现有图形和配色沿用已确认文件；新增组合、字体层级、净空、模板是本轮建议，待所有者验收。正式包只含当前方案，不混入历史探索和 BenchGo 其他研究色。
所有模板均为数字示意，不是印刷就绪稿。未提供 CMYK、Pantone、出血、原生 AI/PSD/Figma 工程或移动应用商店上架认证。PDF 为高清栅格页，SVG 为矢量图形与可编辑文字，未做字体转曲。
不包含用户项目数据库、API 密钥、外部图片或字体二进制。域名来自现有品牌资产，发布前自行确认部署与链接。

## 源文件与复现

所有目录中的 SVG 均为相应可编辑源文件，不重复存放一份。07-源文件保留官方原标识和来源哈希。
在本项目根目录依次执行：
python scripts/build_vi_boards.py
python scripts/build_vi_packages.py
python scripts/build_asset_library.py
字体环境：Windows Segoe UI、微软雅黑。依赖：Python、Pillow、resvg-py。重新生成后校验和会随 PDF 元数据变化，不要求跨次构建逐字节一致。

## 校验

00-使用说明/manifest.json 列出全部交付文件（不含清单自身）的路径、字节数、SHA256；checksums.sha256 包含 manifest.json。清单不自签名，供检查传输完整性使用。
